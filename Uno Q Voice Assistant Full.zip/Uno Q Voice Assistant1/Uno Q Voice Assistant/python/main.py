import serial
import time
import pyttsx3
import speech_recognition as sr
import google.generativeai as genai

# --- 1. CONFIGURATION ---
# Replace with your actual key
GENAI_API_KEY = "YOUR_GEMINI_API_KEY_HERE" 
WAKE_WORD = "hey uno"

# --- 2. SETUP AI & VOICE ---
genai.configure(api_key=GENAI_API_KEY)
model = genai.GenerativeModel('gemini-pro')

# Text-to-Speech Engine
engine = pyttsx3.init()
engine.setProperty('rate', 160) # Speed of voice
engine.setProperty('volume', 1.0)

# Microphone Recognizer
recognizer = sr.Recognizer()

# --- 3. SETUP HARDWARE (ARDUINO) ---
try:
    # Linux/Mac: /dev/ttyACM0 | Windows: COM3
    ser = serial.Serial('/dev/ttyACM0', 115200, timeout=1)
    print("✅ Hardware Connected: Arduino Uno Q")
except:
    ser = None
    print("⚠️ Hardware Warning: Arduino not found. Running in simulation mode.")

# --- 4. HELPER FUNCTIONS ---
def send_command(cmd):
    """Sends a command string to the Arduino."""
    if ser:
        ser.write(f"{cmd}\n".encode('utf-8'))

def speak(text):
    """Speaks text out loud and coordinates the LED."""
    print(f"🤖 AI: {text}")
    
    send_command("LED_ON") # Visual feedback: AI is talking
    engine.say(text)
    engine.runAndWait()
    send_command("LED_OFF") # Visual feedback: Done talking

def listen_for_wake_word():
    """Listens specifically for 'Hey Uno'."""
    with sr.Microphone() as source:
        print("👂 Listening...")
        recognizer.adjust_for_ambient_noise(source)
        try:
            # Short timeout to keep the loop snappy
            audio = recognizer.listen(source, timeout=3, phrase_time_limit=5)
            text = recognizer.recognize_google(audio).lower()
            return text
        except sr.WaitTimeoutError:
            return ""
        except sr.UnknownValueError:
            return ""
        except Exception as e:
            print(f"Error: {e}")
            return ""

# --- 5. MAIN LOOP ---
def main():
    print("🚀 Uno Q Voice Assistant (Headless) is ONLINE.")
    speak("System ready.")

    while True:
        # A. Check for Physical Button Presses
        if ser and ser.in_waiting > 0:
            try:
                line = ser.readline().decode('utf-8').strip()
                if line == "BTN_VOL_UP":
                    print("🎚️ Volume UP")
                    # Optional: Add OS volume control code here
                elif line == "BTN_VOL_DOWN":
                    print("🎚️ Volume DOWN")
            except:
                pass

        # B. Listen for Voice
        user_voice = listen_for_wake_word()
        
        if WAKE_WORD in user_voice:
            print(f"👤 User: {user_voice}")
            send_command("LED_ON") # Acknowledge wake word immediately
            
            # Extract the actual query (remove "hey uno")
            prompt = user_voice.replace(WAKE_WORD, "").strip()
            if not prompt: prompt = "Hello"

            # Ask Gemini
            try:
                response = model.generate_content(prompt)
                speak(response.text)
            except Exception as e:
                speak("I am having trouble connecting to the network.")
            
            send_command("LED_OFF")

if __name__ == '__main__':
    main()